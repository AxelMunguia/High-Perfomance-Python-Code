from multiprocessing import Process


def func_simple(length):
    sum_f1 = 0
    for x in range(0, length):
        sum_f1 += x
    print("Normal sum is {}".format(sum_f1))
    
    
def func_square(length):
    sum_f2 = 0
    for x in range(0, length):
        sum_f2 += x * x
    print("Square sum is {}".format(sum_f2))
    
    
def func_cubes(length):
    sum_f3 = 0
    for x in range(0, length):
        sum_f3 += x * x * x
    print("Cube sum is {}".format(sum_f3))
    
    
def do_Process():
    length = 40
    p = Process(target=func_simple, args=(length,))
    p1 = Process(target=func_square, args=(length,))
    p2 = Process(target=func_cubes, args=(length,))
    # Start execution
    p.start()
    p1.start()
    p2.start()
    # Wait for the threads to finish
    p.join()
    p1.join()
    p2.join()
    
    
if __name__ == "__main__":
    do_Process()