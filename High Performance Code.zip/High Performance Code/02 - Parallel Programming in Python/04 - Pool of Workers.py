import time
from multiprocessing import Pool

def func(x):
    return x * x + x + 3

start = time.time()
for i in range(0, 30000000):
    func(i)
print("It took {} seconds".format(time.time() - start))

## Using a Pool of Workers

# pool.map(f, range(10)) will wait for all 10 of those function calls to finish so we see all the prints in a row. 
# r = pool.map_async(f, range(10)) will execute them asynchronously and only block when r.wait() is called so we 
# see HERE and MORE in between but DONE will always be at the end.


def print_in(x):
    print(x*x)

if __name__ == "__main__":

    start = time.time()
    input_list = range(0, 10) 
    # Blocking call Issue
    with Pool(3) as process_pool: # Blocking Issue
        results =  process_pool.map(print_in, input_list)
    print("It took {} seconds".format(time.time() - start))
    print("Done")
    
    start = time.time()
    pool = Pool(processes=6)
    input_list = range(0, 10) 
    # Non Blocking Issue
    results =  pool.map_async(print_in, input_list)
    
    print("It took {} seconds".format(time.time() - start))
