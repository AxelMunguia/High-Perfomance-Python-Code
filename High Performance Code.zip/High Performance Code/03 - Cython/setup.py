import setuptools
from Cython.Build import cythonize

setuptools.setup(ext_modules = cythonize("loops.pyx"))

# python setup.py build_ext --inplace